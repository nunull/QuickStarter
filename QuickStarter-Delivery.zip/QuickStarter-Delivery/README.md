# Important

The *QuickStarter.jar* can ben launched via `java -jar QuickStarter.jar`. On some systems it also can be double-clicked.

**The system-wide shortcuts for toggling the application may not work when launching the JAR due to problems with the JNI.** Please consider building and launching the whole project using eclipse or ant.